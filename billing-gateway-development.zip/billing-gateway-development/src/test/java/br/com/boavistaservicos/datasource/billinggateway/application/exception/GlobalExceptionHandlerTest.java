package br.com.boavistaservicos.datasource.billinggateway.application.exception;

import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;

public class GlobalExceptionHandlerTest {

    private GlobalExceptionHandler globalExceptionHandler;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        globalExceptionHandler = new GlobalExceptionHandler();
    }

    @Test
    public void testHandleValidationException() {
        BindingResult mockBindingResult = mock(BindingResult.class);
        ObjectError error1 = new ObjectError("field1", "Error message 1");
        when(mockBindingResult.getAllErrors()).thenReturn(Arrays.asList(error1));
        ValidationException validationException = new ValidationException(mockBindingResult);

        ResponseEntity<DataSourceBillingResponse> response = globalExceptionHandler.handleValidationException(validationException);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getBody().getStatus());
        assertEquals("Validation failed", response.getBody().getMessage());
    }
}
