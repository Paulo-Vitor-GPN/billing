package br.com.boavistaservicos.datasource.billinggateway.application.exception;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ValidationExceptionTest {

    @Mock
    private BindingResult mockBindingResult;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testConstructorWithBindingResult() {
        ObjectError error1 = new ObjectError("field1", "Error message 1");
        ObjectError error2 = new ObjectError("field2", "Error message 2");
        when(mockBindingResult.getAllErrors()).thenReturn(Arrays.asList(error1, error2));

        ValidationException exception = new ValidationException(mockBindingResult);

        assertEquals("Validation failed", exception.getMessage());
        assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        assertEquals(2, exception.getErrors().size());
        assertTrue(exception.getErrors().contains("Error message 1"));
        assertTrue(exception.getErrors().contains("Error message 2"));
    }

    @Test
    public void testConstructorWithBindingResultAndStatus() {
        ObjectError error1 = new ObjectError("field1", "Error message 1");
        ObjectError error2 = new ObjectError("field2", "Error message 2");
        when(mockBindingResult.getAllErrors()).thenReturn(Arrays.asList(error1, error2));

        ValidationException exception = new ValidationException(mockBindingResult, HttpStatus.NOT_FOUND);

        assertEquals("Validation failed", exception.getMessage());
        assertEquals(HttpStatus.NOT_FOUND, exception.getStatus());
        assertEquals(2, exception.getErrors().size());
        assertTrue(exception.getErrors().contains("Error message 1"));
        assertTrue(exception.getErrors().contains("Error message 2"));
    }

    @Test
    public void testConstructorWithMessageErrorsAndStatus() {
        List<String> errors = Arrays.asList("Error message 1", "Error message 2");

        ValidationException exception = new ValidationException("Custom message", errors, HttpStatus.BAD_REQUEST);

        assertEquals("Custom message", exception.getMessage());
        assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        assertEquals(2, exception.getErrors().size());
        assertTrue(exception.getErrors().contains("Error message 1"));
        assertTrue(exception.getErrors().contains("Error message 2"));
    }

    @Test
    public void testConstructorWithMessageCauseErrorsAndStatus() {
        List<String> errors = Arrays.asList("Error message 1", "Error message 2");
        Throwable cause = new RuntimeException("Root cause");

        ValidationException exception = new ValidationException("Custom message", cause, errors, HttpStatus.BAD_REQUEST);

        assertEquals("Custom message", exception.getMessage());
        assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        assertEquals(2, exception.getErrors().size());
        assertTrue(exception.getErrors().contains("Error message 1"));
        assertTrue(exception.getErrors().contains("Error message 2"));
        assertEquals(cause, exception.getCause());
    }

    @Test
    public void testConstructorWithErrorsAndStatus() {
        List<String> errors = Arrays.asList("Error message 1", "Error message 2");

        ValidationException exception = new ValidationException(errors, HttpStatus.BAD_REQUEST);

        assertEquals("Validation failed", exception.getMessage());
        assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        assertEquals(2, exception.getErrors().size());
        assertTrue(exception.getErrors().contains("Error message 1"));
        assertTrue(exception.getErrors().contains("Error message 2"));
    }

    @Test
    public void testConstructorWithMessageAndErrors() {
        List<String> errors = Arrays.asList("Error message 1", "Error message 2");

        ValidationException exception = new ValidationException("Custom message", errors);

        assertEquals("Custom message", exception.getMessage());
        assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        assertEquals(2, exception.getErrors().size());
        assertTrue(exception.getErrors().contains("Error message 1"));
        assertTrue(exception.getErrors().contains("Error message 2"));
    }

    @Test
    public void testAddError() {
        ValidationException exception = new ValidationException();

        exception.addError("Error message 1");
        assertNotNull(exception.getErrors());
        assertEquals(1, exception.getErrors().size());
        assertTrue(exception.getErrors().contains("Error message 1"));
    }

    @Test
    public void testAddErrors() {
        ValidationException exception = new ValidationException();
        List<String> errors = Arrays.asList("Error message 1", "Error message 2");

        exception.addErrors(errors);
        assertNotNull(exception.getErrors());
        assertEquals(2, exception.getErrors().size());
        assertTrue(exception.getErrors().contains("Error message 1"));
        assertTrue(exception.getErrors().contains("Error message 2"));
    }

}
