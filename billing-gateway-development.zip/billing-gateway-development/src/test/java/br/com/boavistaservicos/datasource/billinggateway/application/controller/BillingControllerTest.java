package br.com.boavistaservicos.datasource.billinggateway.application.controller;

import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingRequest;
import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingResponse;
import br.com.boavistaservicos.datasource.billinggateway.domain.service.BillingServiceProvider;
import br.com.boavistaservicos.datasource.billinggateway.application.validator.RequestValidator;
import br.com.boavistaservicos.datasource.billinggateway.domain.exceptions.BusinessException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class BillingControllerTest {

    @Mock
    private BillingServiceProvider billingServiceProvider;

    @Mock
    private RequestValidator requestValidator;

    @InjectMocks
    private BillingController billingController;

    @Mock
    private BindingResult bindingResult;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testBilling() throws BusinessException {
        DataSourceBillingRequest requestBody = new DataSourceBillingRequest();
        DataSourceBillingResponse response = new DataSourceBillingResponse();

        when(billingServiceProvider.billing(requestBody)).thenReturn(response);

        ResponseEntity<DataSourceBillingResponse> result = billingController.billing(requestBody ,bindingResult);

        assertEquals(HttpStatus.CREATED, result.getStatusCode());
        assertEquals(response, result.getBody());

        verify(requestValidator).validate(requestBody, bindingResult);
        verify(billingServiceProvider).billing(requestBody);
    }
}
