package br.com.boavistaservicos.datasource.billinggateway.application.validator;

import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingRequest;
import br.com.boavistaservicos.datasource.billinggateway.domain.exceptions.BusinessException;
import br.com.boavistaservicos.datasource.billinggateway.application.exception.ValidationException;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class RequestValidatorTest {

    @Test
    void testValidate_withValidRequest() {
        DataSourceBillingRequest request = new DataSourceBillingRequest();
        BindingResult bindingResult = mock(BindingResult.class);

        RequestValidator validator = new RequestValidator();
        validator.validate(request, bindingResult);

        verify(bindingResult, times(1)).hasErrors();
    }

    @Test
    void testValidate_withNullRequest() {
        BindingResult bindingResult = mock(BindingResult.class);
        RequestValidator validator = new RequestValidator();

        BusinessException exception = assertThrows(BusinessException.class, () -> {
            validator.validate(null, bindingResult);
        });

        assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        assertEquals("Billing invalid body", exception.getMessage());
    }

    @Test
    void testValidate_withBindingErrors() {
        DataSourceBillingRequest request = new DataSourceBillingRequest();
        BindingResult bindingResult = mock(BindingResult.class);
        when(bindingResult.hasErrors()).thenReturn(true);
        when(bindingResult.getAllErrors()).thenReturn(Collections.singletonList(new ObjectError("test", "Invalid value")));

        RequestValidator validator = new RequestValidator();

        ValidationException exception = assertThrows(ValidationException.class, () -> {
            validator.validate(request, bindingResult);
        });

        assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        assertEquals("Validation failed", exception.getMessage());
        assertFalse(exception.getErrors().isEmpty());
        assertEquals("Invalid value", exception.getErrors().get(0));
    }
}


