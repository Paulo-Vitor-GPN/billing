package br.com.boavistaservicos.datasource.billinggateway.domain.service;

import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingRequest;
import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BillingServiceProviderTest {

    @Mock
    private BillingServiceProvider billingServiceProvider;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testBilling() {
        DataSourceBillingRequest request = new DataSourceBillingRequest();
        DataSourceBillingResponse response = new DataSourceBillingResponse();

        when(billingServiceProvider.billing(any(DataSourceBillingRequest.class))).thenReturn(response);
        DataSourceBillingResponse result = billingServiceProvider.billing(request);

        verify(billingServiceProvider, times(1)).billing(request);
        assertSame(response, result);
    }
}
