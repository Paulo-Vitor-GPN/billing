package br.com.boavistaservicos.datasource.billinggateway.domain.service;

import br.com.boavistaservicos.datasource.billinggateway.domain.models.as400.FatLog;
import br.com.boavistaservicos.datasource.billinggateway.domain.models.as400.InformacaoSistemaAssunto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertNotNull;

public class FatLogFormatterTest {

    private FatLogFormatter fatLogFormatter;

    @BeforeEach
    public void setUp() {
        fatLogFormatter = new FatLogFormatter();
    }

    @Test
    public void testFormatToSendToAs() {
        FatLog fatLog = new FatLog.Builder()
                .withDocumento("12345678901")
                .withCodigoCliente("123")
                .withInternetProtocolConsulente("192.168.0.1")
                .withTransactionId("abc123")
                .withInformacaoSistemaAssuntoList(Arrays.asList(
                        new InformacaoSistemaAssunto.Builder()
                                .withCodigoSistema("SYS")
                                .withCodigoAssunto("SUB")
                                .withTipoFaturamento("T")
                                .withMomentoConsulta(LocalDateTime.now())
                                .build()
                ))
                .build();

        String result = fatLogFormatter.formatToSendToAs(fatLog, "codigo", "senha");
        assertNotNull(result);
    }
}

