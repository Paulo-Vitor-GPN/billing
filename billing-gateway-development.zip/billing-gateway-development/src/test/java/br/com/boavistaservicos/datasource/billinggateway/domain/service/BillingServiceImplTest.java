package br.com.boavistaservicos.datasource.billinggateway.domain.service;

import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingRequest;
import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingResponse;
import br.com.boavistaservicos.datasource.billinggateway.domain.exceptions.BusinessException;
import br.com.boavistaservicos.datasource.billinggateway.domain.models.as400.FatLog;
import br.com.boavistaservicos.datasource.billinggateway.domain.models.as400.InformacaoSistemaAssunto;
import br.com.boavistaservicos.datasource.billinggateway.domain.repository.SocketServiceRepositoryInterface;
import br.com.boavistaservicos.datasource.billinggateway.domain.service.impl.BillingServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Arrays;

import static org.assertj.core.api.Fail.fail;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class BillingServiceImplTest {

    @Mock
    private SocketServiceRepositoryInterface repository;

    private BillingServiceImpl billingService;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        billingService = new BillingServiceImpl(repository);
    }


    @Test
    public void testMapperRequestToFatlog() {
        DataSourceBillingRequest request = new DataSourceBillingRequest();
        request.setTipoDocumento("CPF");
        request.setDocumento("12345678900");
        request.setCodigoCliente("CLIENTE123");
        request.setInternetProtocolConsulente("192.168.0.1");
        request.setTransactionId("1234");
        InformacaoSistemaAssunto assunto = new InformacaoSistemaAssunto.Builder()
                .withCodigoSistema("SISTEMA1")
                .withCodigoAssunto("ASSUNTO1")
                .build();
        request.setInformacaoSistemaAssuntoList(Arrays.asList(assunto));

        FatLog fatLog = billingService.mapperRequestToFatlog(request);

        assertNotNull(fatLog);
        assertEquals("CPF", fatLog.getTipoDocumento());
        assertEquals("12345678900", fatLog.getDocumento());
        assertEquals("CLIENTE123", fatLog.getCodigoCliente());
        assertEquals("192.168.0.1", fatLog.getInternetProtocolConsulente());
        assertEquals("1234", fatLog.getTransactionId());
        assertEquals(1, fatLog.getInformacaoSistemaAssuntoList().size());
        assertEquals("SISTEMA1", fatLog.getInformacaoSistemaAssuntoList().get(0).getCodigoSistema());
        assertEquals("ASSUNTO1", fatLog.getInformacaoSistemaAssuntoList().get(0).getCodigoAssunto());
    }

    @Test
    public void testCreateErrorResponse() {
        DataSourceBillingResponse response = billingService.createErrorResponse("Error message", 500);

        assertNotNull(response);

        assertEquals("Error message", response.getMessage());
        assertEquals(500, response.getStatus());
    }

    @Test
    public void testValidateBillingInformation_InvalidCPF() {
        // Mock a DataSourceBillingRequest with an invalid CPF
        DataSourceBillingRequest request = new DataSourceBillingRequest();
        request.setDocumento("12345678900"); // Invalid CPF

        // Call the method to be tested and expect BusinessException
        try {
            billingService.validateBillingInformation(request);
            fail("Expected BusinessException");
        } catch (BusinessException ex) {
            assertEquals("CPF inválido!", ex.getMessage());
        }
    }

    @Test
    public void testValidateBillingInformation_EmptySystemSubjectList() {
        // Mock a DataSourceBillingRequest with an empty system subject list
        DataSourceBillingRequest request = new DataSourceBillingRequest();
        request.setDocumento("12345678900"); // Valid CPF
        request.setInformacaoSistemaAssuntoList(new ArrayList<>());

        // Call the method to be tested and expect BusinessException
        try {
            billingService.validateBillingInformation(request);
            fail("Expected BusinessException");
        } catch (BusinessException ex) {
            assertEquals("CPF inválido!", ex.getMessage());
        }
    }
}
