package br.com.boavistaservicos.datasource.billinggateway.infrastructure.client;

import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingResponse;
import br.com.boavistaservicos.datasource.billinggateway.domain.models.as400.FatLog;
import br.com.boavistaservicos.datasource.billinggateway.domain.repository.SocketServiceRepositoryInterface;
import br.com.boavistaservicos.datasource.billinggateway.domain.service.FatLogFormatter;
import br.com.boavistaservicos.datasource.billinggateway.domain.service.ResponseFormatter;
import br.com.boavistaservicos.datasource.billinggateway.infrastructure.client.impl.SocketServiceRepositoryImpl;
import br.com.boavistaservicos.datasource.billinggateway.infrastructure.config.SocketServiceConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class SocketServiceRepositoryImplTest {

    @Mock
    private As400Client as400Client;

    @Mock
    private SocketServiceConfig socketServiceConfig;

    @Mock
    private FatLogFormatter fatLogFormatter;

    @Mock
    private ResponseFormatter responseFormatter;

    private SocketServiceRepositoryInterface socketServiceRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
        socketServiceRepository = new SocketServiceRepositoryImpl(as400Client, socketServiceConfig, fatLogFormatter, responseFormatter);

        // Configurando mocks
        when(socketServiceConfig.getSocketServiceCodigo()).thenReturn("codigo");
        when(socketServiceConfig.getSocketServiceSenha()).thenReturn("senha");
    }

    @Test
    void sendToSocket_Success() {
        FatLog fatLog = new FatLog.Builder()
                .withDocumento("BV2HOM")
                .withCodigoCliente("00395243")
                .withInternetProtocolConsulente("194.168.1.1")
                .withTransactionId("00000000000000000000040955795616467122")
                .build();

        String formattedRequest = "formattedRequest";
        String responseFromAs400 = "CSR61   01          080923-133915       00395243FATLOG  072000046540102099931S00GRAVACAO REALIZADA COM SUCESSO";
        DataSourceBillingResponse expectedResponse = new DataSourceBillingResponse();
        expectedResponse.setMessage("GRAVACAO REALIZADA COM SUCESSO");
        expectedResponse.setStatus(200);

        when(fatLogFormatter.formatToSendToAs(any(FatLog.class), any(String.class), any(String.class))).thenReturn(formattedRequest);
        when(as400Client.sendToAs400(any(String.class))).thenReturn(responseFromAs400);
        when(responseFormatter.formatResponseAs(any(String.class))).thenReturn(expectedResponse);

        DataSourceBillingResponse response = socketServiceRepository.sendToSocket(fatLog);

        assertNotNull(response, "A resposta não deve ser nula");
        assertEquals(expectedResponse.getMessage(), response.getMessage());
        assertEquals(expectedResponse.getStatus(), response.getStatus());
    }

    @Test
    void sendToSocket_Failure() {
        FatLog fatLog = new FatLog.Builder()
                .withDocumento("BV2HOM")
                .withCodigoCliente("00395243")
                .withInternetProtocolConsulente("194.168.1.1")
                .withTransactionId("00000000000000000000040955795616467122")
                .build();

        String formattedRequest = "formattedRequest";
        String responseFromAs400 = "CSR61   01                              00395243FATLOG  072900000000101098999* NUMERO DO IP NAO INFORMADO";
        DataSourceBillingResponse expectedResponse = new DataSourceBillingResponse();
        expectedResponse.setMessage("NUMERO DO IP NAO INFORMADO");
        expectedResponse.setStatus(999);

        when(fatLogFormatter.formatToSendToAs(any(FatLog.class), any(String.class), any(String.class))).thenReturn(formattedRequest);
        when(as400Client.sendToAs400(any(String.class))).thenReturn(responseFromAs400);
        when(responseFormatter.formatResponseAs(any(String.class))).thenReturn(expectedResponse);

        DataSourceBillingResponse response = socketServiceRepository.sendToSocket(fatLog);

        assertNotNull(response, "A resposta não deve ser nula");
        assertEquals(expectedResponse.getMessage(), response.getMessage());
        assertEquals(expectedResponse.getStatus(), response.getStatus());
    }
}