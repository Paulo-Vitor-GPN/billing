package br.com.boavistaservicos.datasource.billinggateway.domain.service;

import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class ResponseFormatterTest {

    private ResponseFormatter responseFormatter;

    @BeforeEach
    public void setUp() {
        responseFormatter = new ResponseFormatter();
    }

    @Test
    public void testFormatResponseAs_UnknownType() {
        String response = "<PRE>CSR61   01                              00395243FATLOG  072900000000101098XXX* UNKOWN TYPE       </PRE>\n";
        DataSourceBillingResponse result = responseFormatter.formatResponseAs(response);
        assertNotNull(result);
        assertEquals("Ocorreu uma falha no processamento", result.getMessage());
        assertEquals(999, result.getStatus());
    }

    @Test
    public void testFormatResponseAs_EmptyResponse() {
        String response = "";
        DataSourceBillingResponse result = responseFormatter.formatResponseAs(response);
        assertNotNull(result);
        assertEquals("Ocorreu uma falha no processamento", result.getMessage());
        assertEquals(999, result.getStatus());
    }

    @Test
    public void testFormatResponseAs_NullResponse() {
        String response = null;
        DataSourceBillingResponse result = responseFormatter.formatResponseAs(response);
        assertNotNull(result);
        assertEquals("Ocorreu uma falha no processamento", result.getMessage());
        assertEquals(999, result.getStatus());
    }

    @Test
    public void testFormatResponseAs_InvalidResponse() {
        String response = "<PRE>Invalid response format</PRE>\n";
        DataSourceBillingResponse result = responseFormatter.formatResponseAs(response);
        assertNotNull(result);
        assertEquals("Ocorreu uma falha no processamento", result.getMessage());
        assertEquals(999, result.getStatus());
    }
}
