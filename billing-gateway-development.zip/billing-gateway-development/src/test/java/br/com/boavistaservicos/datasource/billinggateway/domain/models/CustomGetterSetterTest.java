package br.com.boavistaservicos.datasource.billinggateway.domain.models;

import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingRequest;
import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingResponse;
import br.com.boavistaservicos.datasource.billinggateway.domain.models.as400.FatLog;
import br.com.boavistaservicos.datasource.billinggateway.domain.models.as400.InformacaoSistemaAssunto;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class CustomGetterSetterTest {

    @Test
    void getterSetterTest() {
        assertThat(GetterSetterVerifier.forClass(FatLog.class).verify()).isTrue();
        assertThat(GetterSetterVerifier.forClass(InformacaoSistemaAssunto.class).verify()).isTrue();
        assertThat(GetterSetterVerifier.forClass(AuthenticationToken.class).verify()).isTrue();
        assertThat(GetterSetterVerifier.forClass(DataSourceBillingRequest.class).verify()).isTrue();
        assertThat(GetterSetterVerifier.forClass(DataSourceBillingResponse.class).verify()).isTrue();
        assertThat(GetterSetterVerifier.forClass(AuthenticationToken.class).verify()).isTrue();
    }
}
