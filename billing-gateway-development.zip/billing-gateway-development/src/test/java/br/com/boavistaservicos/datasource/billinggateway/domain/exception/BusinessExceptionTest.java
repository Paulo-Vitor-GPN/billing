package br.com.boavistaservicos.datasource.billinggateway.domain.exception;

import br.com.boavistaservicos.datasource.billinggateway.domain.exceptions.BusinessException;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class BusinessExceptionTest {

    @Test
    void testConstructorWithMessage() {
        String errorMessage = "Test error message";
        BusinessException exception = new BusinessException(errorMessage);

        assertEquals(errorMessage, exception.getMessage());
        assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        assertNotNull(exception.toString());
    }

    @Test
    void testConstructorWithMessageAndStatus() {
        String errorMessage = "Test error message";
        HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
        BusinessException exception = new BusinessException(errorMessage, status);

        assertEquals(errorMessage, exception.getMessage());
        assertEquals(status, exception.getStatus());
        assertNotNull(exception.toString());
    }

    @Test
    void testConstructorWithMessageStatusAndCause() {
        String errorMessage = "Test error message";
        HttpStatus status = HttpStatus.NOT_FOUND;
        Throwable cause = new RuntimeException("Test cause");
        BusinessException exception = new BusinessException(errorMessage, cause, status);

        assertEquals(errorMessage, exception.getMessage());
        assertEquals(status, exception.getStatus());
        assertEquals(cause, exception.getCause());
        assertNotNull(exception.toString());
    }
}
