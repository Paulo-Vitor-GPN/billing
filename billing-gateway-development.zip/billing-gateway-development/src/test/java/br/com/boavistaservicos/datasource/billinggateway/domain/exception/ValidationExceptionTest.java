package br.com.boavistaservicos.datasource.billinggateway.domain.exception;

import br.com.boavistaservicos.datasource.billinggateway.application.exception.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class ValidationExceptionTest {

    private BindingResult bindingResult;

    @BeforeEach
    void setUp() {
        bindingResult = Mockito.mock(BindingResult.class);
    }


    @Test
    void testValidationExceptionWithMessageAndErrors() {
        List<String> errors = List.of("Error 1", "Error 2");
        ValidationException exception = new ValidationException("Custom message", errors);

        assertEquals("Custom message", exception.getMessage());
        assertNotNull(exception.getErrors());
        assertEquals(2, exception.getErrors().size());
        assertEquals("Error 1", exception.getErrors().get(0));
    }

    @Test
    void testAddError() {
        List<String> errors = List.of("New error");

        ValidationException exception = new ValidationException("",errors);
        assertEquals(1, exception.getErrors().size());
        assertEquals("New error", exception.getErrors().get(0));
    }

    @Test
    void testAddErrors() {
        List<String> errors = List.of("New error 1", "New error 2");

        ValidationException exception = new ValidationException("", errors);
        assertEquals(2, exception.getErrors().size());
        assertEquals("New error 1", exception.getErrors().get(0));
        assertEquals("New error 2", exception.getErrors().get(1));
    }
}
