package br.com.boavistaservicos.datasource.billinggateway.domain.service.impl;

import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingRequest;
import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingResponse;
import br.com.boavistaservicos.datasource.billinggateway.domain.exceptions.BusinessException;
import br.com.boavistaservicos.datasource.billinggateway.domain.models.as400.FatLog;
import br.com.boavistaservicos.datasource.billinggateway.domain.repository.SocketServiceRepositoryInterface;
import br.com.boavistaservicos.datasource.billinggateway.domain.service.BillingServiceProvider;
import br.com.boavistaservicos.datasource.billinggateway.domain.utils.ValidateDocument;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BillingServiceImpl extends ValidateDocument implements BillingServiceProvider {

    private static final Logger LOGGER = LoggerFactory.getLogger(BillingServiceImpl.class);
    private final SocketServiceRepositoryInterface repository;


    @Autowired
    public BillingServiceImpl(SocketServiceRepositoryInterface repository) {
        this.repository = repository;
    }

    @Override
    public DataSourceBillingResponse billing(DataSourceBillingRequest requestBody) {
        try {
            validateBillingInformation(requestBody);
            LOGGER.info("Etapa: {}, Mensagem: {}, requestBody: {}", "processamento de bilhetagem", "Início", requestBody);
            FatLog fatLog = mapperRequestToFatlog(requestBody);
            return repository.sendToSocket(fatLog);
        } catch (Exception ex) {
            LOGGER.error("Etapa: {}, Mensagem: {}, requestBody: {}", "processamento de bilhetagem - BillingService ", ex.getMessage(), requestBody);
            return createErrorResponse("falha no processamento", 999);
        }
    }

    public void validateBillingInformation(DataSourceBillingRequest requestBody) throws BusinessException {
        if (!isValidCPF(requestBody.getDocumento())) {
            throw new BusinessException("CPF inválido!");
        }
        if (requestBody.getInformacaoSistemaAssuntoList() == null || requestBody.getInformacaoSistemaAssuntoList().isEmpty()) {
            throw new BusinessException("Sistema assunto inválido!");
        }
    }

    public DataSourceBillingResponse createErrorResponse(String message, int status) {
        DataSourceBillingResponse response = new DataSourceBillingResponse();
        response.setMessage(message);
        response.setStatus(status);
        LOGGER.info("Etapa: {}, Mensagem: {}", "processamento de bilhetagem - ERROR", response);
        return response;
    }

    public FatLog mapperRequestToFatlog(DataSourceBillingRequest requestBody) {
        FatLog fatLog = new FatLog.Builder()
                .withTipoDocumento(requestBody.getTipoDocumento())
                .withDocumento(requestBody.getDocumento())
                .withCodigoCliente(requestBody.getCodigoCliente())
                .withInternetProtocolConsulente(requestBody.getInternetProtocolConsulente())
                .withTransactionId(requestBody.getTransactionId())
                .withInformacaoSistemaAssuntoList(requestBody.getInformacaoSistemaAssuntoList())
                .build();
        LOGGER.info("Etapa: {}, Message: {}, fatlog: {}", "Mapper - fatlog", "Montando fatlog com dados da request", fatLog);
        return fatLog;
    }
}
