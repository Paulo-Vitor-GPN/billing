package br.com.boavistaservicos.datasource.billinggateway.infrastructure;

import org.springframework.context.annotation.ComponentScan;
@ComponentScan
public interface InfrastructureScanMarker {
}
