package br.com.boavistaservicos.datasource.billinggateway.application.controller;

import br.com.boavistaservicos.datasource.billinggateway.application.validator.RequestValidator;
import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingRequest;
import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingResponse;
import br.com.boavistaservicos.datasource.billinggateway.domain.exceptions.BusinessException;
import br.com.boavistaservicos.datasource.billinggateway.domain.service.BillingServiceProvider;
import io.swagger.v3.oas.annotations.Operation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/billing")
public class BillingController {
    private static final Logger LOGGER = LoggerFactory.getLogger(BillingController.class);
    private final BillingServiceProvider billingServiceProvider;
    private final RequestValidator requestValidator;

    @Autowired
    public BillingController(BillingServiceProvider billingServiceProvider, RequestValidator requestValidator) {
        this.billingServiceProvider = billingServiceProvider;
        this.requestValidator = requestValidator;
    }

    @Operation(summary = "Saudação de exemplo")
    @PostMapping
    public ResponseEntity<DataSourceBillingResponse> billing(@RequestBody DataSourceBillingRequest requestBody, BindingResult result) throws BusinessException {
        LOGGER.info("Etapa: {}, Request body: {}", "START BILLING", requestBody);

        requestValidator.validate(requestBody, result);

        DataSourceBillingResponse response  = billingServiceProvider.billing(requestBody);

        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }
}
