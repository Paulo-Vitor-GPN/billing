package br.com.boavistaservicos.datasource.billinggateway.application.exception;

import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Getter
@NoArgsConstructor
public class ValidationException extends RuntimeException implements Serializable {

    private static final long serialVersionUID = 1L;
    private List<String> errors;
    private HttpStatus status;

    public ValidationException(BindingResult result) {
        super("Validation failed");
        this.errors = result.getAllErrors().stream()
                .map(ObjectError::getDefaultMessage)
                .collect(Collectors.toList());
        this.status = HttpStatus.BAD_REQUEST;
    }

    public ValidationException(BindingResult result, HttpStatus status) {
        super("Validation failed");
        this.errors = result.getAllErrors().stream()
                .map(ObjectError::getDefaultMessage)
                .collect(Collectors.toList());
        this.status = status;
    }

    public ValidationException(String message, List<String> errors, HttpStatus status) {
        super(message);
        this.errors = errors;
        this.status = status;
    }

    public ValidationException(String message, Throwable cause, List<String> errors, HttpStatus status) {
        super(message, cause);
        this.errors = errors;
        this.status = status;
    }

    public ValidationException(List<String> errors, HttpStatus status) {
        super("Validation failed");
        this.errors = errors;
        this.status = status;
    }

    public ValidationException(String message, List<String> errors) {
        super(message);
        this.errors = errors;
        this.status = HttpStatus.BAD_REQUEST;
    }

    public void addError(String error) {
        if (this.errors == null) {
            this.errors = new ArrayList<>();
        }
        this.errors.add(error);
    }

    public void addErrors(List<String> errors) {
        if (this.errors == null) {
            this.errors = new ArrayList<>();
        }
        this.errors.addAll(errors);
    }

    @Override
    public String toString() {
        return "ValidationException{" +
                "errors=" + errors +
                ", status=" + status +
                ", message='" + getMessage() + '\'' +
                '}';
    }
}
