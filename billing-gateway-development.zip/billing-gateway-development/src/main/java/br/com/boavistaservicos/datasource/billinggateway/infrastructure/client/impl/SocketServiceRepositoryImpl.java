package br.com.boavistaservicos.datasource.billinggateway.infrastructure.client.impl;
import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingResponse;
import br.com.boavistaservicos.datasource.billinggateway.domain.models.as400.FatLog;
import br.com.boavistaservicos.datasource.billinggateway.domain.repository.SocketServiceRepositoryInterface;
import br.com.boavistaservicos.datasource.billinggateway.domain.service.FatLogFormatter;
import br.com.boavistaservicos.datasource.billinggateway.domain.service.ResponseFormatter;
import br.com.boavistaservicos.datasource.billinggateway.infrastructure.client.As400Client;
import br.com.boavistaservicos.datasource.billinggateway.infrastructure.config.SocketServiceConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

@Repository
public class SocketServiceRepositoryImpl implements SocketServiceRepositoryInterface {
    private static final Logger LOGGER = LoggerFactory.getLogger(SocketServiceRepositoryImpl.class);
    private final As400Client as400Client;
    private final SocketServiceConfig socketServiceConfig;
    private final FatLogFormatter fatLogFormatter;
    private final ResponseFormatter responseFormatter;

    public SocketServiceRepositoryImpl(As400Client as400Client, SocketServiceConfig socketServiceConfig,
                                       FatLogFormatter fatLogFormatter, ResponseFormatter responseFormatter) {
        this.as400Client = as400Client;
        this.socketServiceConfig = socketServiceConfig;
        this.fatLogFormatter = fatLogFormatter;
        this.responseFormatter = responseFormatter;
    }

    @Override
    public DataSourceBillingResponse sendToSocket(FatLog fatLog) {
        String formattedFatlog = fatLogFormatter.formatToSendToAs(fatLog, socketServiceConfig.getSocketServiceCodigo(), socketServiceConfig.getSocketServiceSenha());
        String response = as400Client.sendToAs400(formattedFatlog);
        return responseFormatter.formatResponseAs(response);
    }
}
