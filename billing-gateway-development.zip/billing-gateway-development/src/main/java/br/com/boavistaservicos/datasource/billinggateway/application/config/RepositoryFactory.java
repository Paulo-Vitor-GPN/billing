package br.com.boavistaservicos.datasource.billinggateway.application.config;

import br.com.boavistaservicos.datasource.billinggateway.domain.repository.SocketServiceRepositoryInterface;
import br.com.boavistaservicos.datasource.billinggateway.domain.service.FatLogFormatter;
import br.com.boavistaservicos.datasource.billinggateway.domain.service.ResponseFormatter;
import br.com.boavistaservicos.datasource.billinggateway.infrastructure.InfrastructureScanMarker;
import br.com.boavistaservicos.datasource.billinggateway.infrastructure.client.As400Client;
import br.com.boavistaservicos.datasource.billinggateway.infrastructure.client.impl.SocketServiceRepositoryImpl;
import br.com.boavistaservicos.datasource.billinggateway.infrastructure.config.SocketServiceConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableFeignClients(basePackageClasses = InfrastructureScanMarker.class)
@ComponentScan({"br.com.boavistaservicos.datasource.billinggateway.infrastructure.config", "br.com.boavistaservicos.datasource.billinggateway.domain.service"})
public class RepositoryFactory {

    private final As400Client as400Client;
    private final SocketServiceConfig socketServiceConfig;
    private final FatLogFormatter fatLogFormatter;
    private final ResponseFormatter responseFormatter;

    @Autowired
    public RepositoryFactory(As400Client as400Client, SocketServiceConfig socketServiceConfig,
                             FatLogFormatter fatLogFormatter, ResponseFormatter responseFormatter) {
        this.as400Client = as400Client;
        this.socketServiceConfig = socketServiceConfig;
        this.fatLogFormatter = fatLogFormatter;
        this.responseFormatter = responseFormatter;
    }

    @Bean
    public SocketServiceRepositoryInterface socketServiceRepositoryInterface() {
        return new SocketServiceRepositoryImpl(as400Client, socketServiceConfig, fatLogFormatter, responseFormatter);
    }
}