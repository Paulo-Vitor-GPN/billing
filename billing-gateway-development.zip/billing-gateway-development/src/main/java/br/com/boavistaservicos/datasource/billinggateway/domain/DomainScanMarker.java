package br.com.boavistaservicos.datasource.billinggateway.domain;

public interface DomainScanMarker {
}
