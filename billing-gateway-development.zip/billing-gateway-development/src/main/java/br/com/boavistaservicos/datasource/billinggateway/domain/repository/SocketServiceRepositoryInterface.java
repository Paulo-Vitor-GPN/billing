package br.com.boavistaservicos.datasource.billinggateway.domain.repository;

import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingResponse;
import br.com.boavistaservicos.datasource.billinggateway.domain.models.as400.FatLog;

public interface SocketServiceRepositoryInterface {
   DataSourceBillingResponse sendToSocket(FatLog fatLog);
}
