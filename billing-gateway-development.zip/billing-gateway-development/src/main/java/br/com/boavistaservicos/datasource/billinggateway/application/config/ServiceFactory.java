package br.com.boavistaservicos.datasource.billinggateway.application.config;

import br.com.boavistaservicos.datasource.billinggateway.domain.repository.SocketServiceRepositoryInterface;
import br.com.boavistaservicos.datasource.billinggateway.domain.service.BillingServiceProvider;
import br.com.boavistaservicos.datasource.billinggateway.domain.service.impl.BillingServiceImpl;
import br.com.boavistaservicos.datasource.billinggateway.domain.utils.ValidateDocument;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ServiceFactory {

    @Bean
    public BillingServiceProvider billingServiceProvider(SocketServiceRepositoryInterface repository, ValidateDocument validateDocument) {
        return new BillingServiceImpl(repository);
    }

}
