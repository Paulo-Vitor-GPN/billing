package br.com.boavistaservicos.datasource.billinggateway.infrastructure.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "As400Client", url = "${socket.service.url}")
public interface As400Client {
    @GetMapping(value = "/socket?consulta={param}")
    String sendToAs400(@PathVariable(value = "param") String param);
}
