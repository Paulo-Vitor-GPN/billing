package br.com.boavistaservicos.datasource.billinggateway.application.validator;

import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingRequest;
import br.com.boavistaservicos.datasource.billinggateway.domain.exceptions.BusinessException;
import br.com.boavistaservicos.datasource.billinggateway.application.exception.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;

@Component
@Validated
public class RequestValidator {

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestValidator.class);

    public void validate(DataSourceBillingRequest requestBody, BindingResult result) throws BusinessException {
        LOGGER.info("Etapa: {}, requestBody: {}", "validacao chamada", requestBody);
        validateRequestBody(requestBody);
        validateBindingResult(result);
    }

    private void validateRequestBody(DataSourceBillingRequest requestBody) throws BusinessException {
        if (requestBody == null) {
            LOGGER.error("Etapa: {}", "validacao Request Body");
            throw new BusinessException("Billing invalid body", HttpStatus.BAD_REQUEST);
        }
    }

    private void validateBindingResult(BindingResult result) {
        if (result.hasErrors()) {
            LOGGER.error("Etapa: {}, validacao erros: {}", "validate BindingResult ", result.getAllErrors());
            throw new ValidationException(result, HttpStatus.BAD_REQUEST);
        }
    }

}
