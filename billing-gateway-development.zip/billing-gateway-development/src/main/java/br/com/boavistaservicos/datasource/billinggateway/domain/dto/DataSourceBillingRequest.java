package br.com.boavistaservicos.datasource.billinggateway.domain.dto;

import br.com.boavistaservicos.datasource.billinggateway.domain.models.as400.InformacaoSistemaAssunto;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
public class DataSourceBillingRequest {

    @JsonProperty("tipoDocumento")
    private String tipoDocumento;

    @JsonProperty("documento")
    private String documento;

    @JsonProperty("codigoCliente")
    private String codigoCliente;

    @JsonProperty("internetProtocolConsulente")
    private String internetProtocolConsulente;

    @JsonProperty("transactionId")
    private String transactionId;

    @JsonProperty("informacaoSistemaAssuntoList")
    private List<InformacaoSistemaAssunto> informacaoSistemaAssuntoList;

}
