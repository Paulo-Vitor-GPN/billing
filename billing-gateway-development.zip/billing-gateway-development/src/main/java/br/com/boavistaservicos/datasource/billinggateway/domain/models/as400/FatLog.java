package br.com.boavistaservicos.datasource.billinggateway.domain.models.as400;

import lombok.Getter;
import lombok.ToString;

import java.util.List;

@Getter
@ToString
public class FatLog {
    private String transacao = "CSR60   ";
    private String versao = "01";
    private String reservadoSolicitante;  // ver define
    private String reservadoBoaVistaServicos; // ver define
    private String codigoServico; // ver define
    private String senhaAcesso; // ver define
    private String codigoConsulta = "FATLOG  ";
    private String versaoConsulta = "07";
    private String tipoResposta = "2"; // Analitica
    private String tipoTransmissaoResposta = "T"; // Transacional
    private String tipoDocumento;
    private String documento;
    private String codigoCliente;
    private String internetProtocolConsulente;
    private String transactionId;
    private List<InformacaoSistemaAssunto> informacaoSistemaAssuntoList;

    public FatLog(String transacao, String versao, String reservadoSolicitante, String reservadoBoaVistaServicos,
                  String codigoServico, String senhaAcesso, String codigoConsulta, String versaoConsulta,
                  String tipoResposta, String tipoTransmissaoResposta, String tipoDocumento, String documento,
                  String codigoCliente, String internetProtocolConsulente, String transactionId,
                  List<InformacaoSistemaAssunto> informacaoSistemaAssuntoList) {
        this.transacao = transacao;
        this.versao = versao;
        this.reservadoSolicitante = reservadoSolicitante;
        this.reservadoBoaVistaServicos = reservadoBoaVistaServicos;
        this.codigoServico = codigoServico;
        this.senhaAcesso = senhaAcesso;
        this.codigoConsulta = codigoConsulta;
        this.versaoConsulta = versaoConsulta;
        this.tipoResposta = tipoResposta;
        this.tipoTransmissaoResposta = tipoTransmissaoResposta;
        this.tipoDocumento = tipoDocumento;
        this.documento = documento;
        this.codigoCliente = codigoCliente;
        this.internetProtocolConsulente = internetProtocolConsulente;
        this.transactionId = transactionId;
        this.informacaoSistemaAssuntoList = informacaoSistemaAssuntoList;
    }

    public FatLog(Builder builder) {
        transacao = builder.transacao;
        versao = builder.versao;
        reservadoSolicitante = builder.reservadoSolicitante;
        reservadoBoaVistaServicos = builder.reservadoBoaVistaServicos;
        codigoServico = builder.codigoServico;
        senhaAcesso = builder.senhaAcesso;
        codigoConsulta = builder.codigoConsulta;
        versaoConsulta = builder.versaoConsulta;
        tipoResposta = builder.tipoResposta;
        tipoTransmissaoResposta = builder.tipoTransmissaoResposta;
        tipoDocumento = builder.tipoDocumento;
        documento = builder.documento;
        codigoCliente = builder.codigoCliente;
        internetProtocolConsulente = builder.internetProtocolConsulente;
        transactionId = builder.trasactionId;
        informacaoSistemaAssuntoList = builder.informacaoSistemaAssuntoList;
    }


    public static final class Builder {
        private String transacao;
        private String versao;
        private String reservadoSolicitante;
        private String reservadoBoaVistaServicos;
        private String codigoServico;
        private String senhaAcesso;
        private String codigoConsulta;
        private String versaoConsulta;
        private String tipoResposta;
        private String tipoTransmissaoResposta;
        private String tipoDocumento;
        private String documento;
        private String codigoCliente;
        private String internetProtocolConsulente;
        private String trasactionId;
        private List<InformacaoSistemaAssunto> informacaoSistemaAssuntoList;

        public Builder() {
        }

        public static Builder builder() {
            return new Builder();
        }

        public Builder withTransacao(String val) {
            transacao = val;
            return this;
        }

        public Builder withVersao(String val) {
            versao = val;
            return this;
        }

        public Builder withReservadoSolicitante(String val) {
            reservadoSolicitante = val;
            return this;
        }

        public Builder withReservadoBoaVistaServicos(String val) {
            reservadoBoaVistaServicos = val;
            return this;
        }

        public Builder withCodigoServico(String val) {
            codigoServico = val;
            return this;
        }

        public Builder withSenhaAcesso(String val) {
            senhaAcesso = val;
            return this;
        }

        public Builder withCodigoConsulta(String val) {
            codigoConsulta = val;
            return this;
        }

        public Builder withVersaoConsulta(String val) {
            versaoConsulta = val;
            return this;
        }

        public Builder withTipoResposta(String val) {
            tipoResposta = val;
            return this;
        }

        public Builder withTipoTransmissaoResposta(String val) {
            tipoTransmissaoResposta = val;
            return this;
        }

        public Builder withTipoDocumento(String val) {
            tipoDocumento = val;
            return this;
        }

        public Builder withDocumento(String val) {
            documento = val;
            return this;
        }

        public Builder withCodigoCliente(String val) {
            codigoCliente = val;
            return this;
        }

        public Builder withInternetProtocolConsulente(String val) {
            internetProtocolConsulente = val;
            return this;
        }

        public Builder withTransactionId(String val) {
            trasactionId = val;
            return this;
        }

        public Builder withInformacaoSistemaAssuntoList(List<InformacaoSistemaAssunto> val) {
            informacaoSistemaAssuntoList = val;
            return this;
        }

        public FatLog build() {
            return new FatLog(this);
        }
    }

}
