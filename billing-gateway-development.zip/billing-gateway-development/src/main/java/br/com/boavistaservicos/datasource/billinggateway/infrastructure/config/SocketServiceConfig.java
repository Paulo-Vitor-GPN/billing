package br.com.boavistaservicos.datasource.billinggateway.infrastructure.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SocketServiceConfig {

    @Value("${socket.service.codigo}")
    private String socketServiceCodigo;

    @Value("${socket.service.senha}")
    private String socketServiceSenha;

    @Value("${socket.service.url}")
    private String socketServiceUrl;

    public String getSocketServiceCodigo() {
        return socketServiceCodigo;
    }

    public String getSocketServiceSenha() {
        return socketServiceSenha;
    }

    public String getSocketServiceUrl() {
        return socketServiceUrl;
    }
}
