package br.com.boavistaservicos.datasource.billinggateway.domain.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DataSourceBillingResponse{

    @JsonProperty("status")
    private long status;

    @JsonProperty("message")
    private String message;
}
