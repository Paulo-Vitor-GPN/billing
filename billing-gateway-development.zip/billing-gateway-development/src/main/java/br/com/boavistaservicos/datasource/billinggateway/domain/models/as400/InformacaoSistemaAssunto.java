package br.com.boavistaservicos.datasource.billinggateway.domain.models.as400;

import lombok.Getter;
import lombok.ToString;

import java.time.LocalDateTime;

/*
@Autor: xxxx
*/

@Getter
@ToString
public class InformacaoSistemaAssunto {
    private String codigoSistema;
    private String codigoAssunto;
    private String validarAutorizacaoCliente = "N";
    private String tipoFaturamento;
    private LocalDateTime momentoConsulta;  // HHMMSS

    public InformacaoSistemaAssunto(String codigoSistema, String codigoAssunto, String validarAutorizacaoCliente,
                                    String tipoFaturamento, LocalDateTime momentoConsulta, String codModeloScoreEnv,
                                    String respModeloScoreEnv, String respModeloScoreCalc) {
        this.codigoSistema = codigoSistema;
        this.codigoAssunto = codigoAssunto;
        this.validarAutorizacaoCliente = validarAutorizacaoCliente;
        this.tipoFaturamento = tipoFaturamento;
        this.momentoConsulta = momentoConsulta;
    }

    private InformacaoSistemaAssunto(Builder builder) {
        codigoSistema = builder.codigoSistema;
        codigoAssunto = builder.codigoAssunto;
        validarAutorizacaoCliente = builder.validarAutorizacaoCliente;
        tipoFaturamento = builder.tipoFaturamento;
        momentoConsulta = builder.momentoConsulta;
    }

    public InformacaoSistemaAssunto() {
    }

    public static class Builder {

        private String codigoSistema;
        private String codigoAssunto;
        private String validarAutorizacaoCliente;
        private String tipoFaturamento;
        private LocalDateTime momentoConsulta;

        public Builder() {
        }

        public static Builder builder() {
            return new Builder();
        }

        public Builder withCodigoSistema(String val) {
            codigoSistema = val;
            return this;
        }

        public Builder withCodigoAssunto(String val) {
            codigoAssunto = val;
            return this;
        }

        public Builder withValidarAutorizacaoCliente(String val) {
            validarAutorizacaoCliente = val;
            return this;
        }

        public Builder withTipoFaturamento(String val) {
            tipoFaturamento = val;
            return this;
        }

        public Builder withMomentoConsulta(LocalDateTime val) {
            momentoConsulta = val;
            return this;
        }

        public InformacaoSistemaAssunto build() {
            return new InformacaoSistemaAssunto(this);
        }
    }
}
