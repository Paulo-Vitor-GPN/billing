package br.com.boavistaservicos.datasource.billinggateway.domain.service;

import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class ResponseFormatter {

    private static final Logger LOGGER = LoggerFactory.getLogger(ResponseFormatter.class);
    private static final String TIPO_REGISTRO_ERRO = "999";
    private static final String TIPO_REGISTRO_OK = "931";

    public DataSourceBillingResponse formatResponseAs(String response) {
        DataSourceBillingResponse billingResponse = new DataSourceBillingResponse();
        LOGGER.info("Etapa: {}", "Iniciando formatação da resposta");
        try {
            int registroStartIndex = 74;
            int registroEndIndex = 77;
            String cleanedResponse = response.replace("<PRE>", "").replace("</PRE>", "").replace("\n", "");
            String registro = cleanedResponse.substring(registroStartIndex, registroEndIndex).trim();


            String message;
            int status;

            if (registro.equals(TIPO_REGISTRO_ERRO)) {
                int messageStartIndex = 79;
                message = cleanedResponse.substring(messageStartIndex).trim();
                status = Integer.parseInt(cleanedResponse.substring(59, 60).trim());
            } else if (registro.equals(TIPO_REGISTRO_OK)) {
                int messageStartIndex = 80;
                message = cleanedResponse.substring(messageStartIndex).trim();
                status = Integer.parseInt(cleanedResponse.substring(registroStartIndex, registroEndIndex));
            } else {
                throw new IllegalArgumentException("Tipo de registro desconhecido: " + registro);
            }

            billingResponse.setMessage(message);
            billingResponse.setStatus(status);
        } catch (Exception ex) {
            LOGGER.error("Erro ao formatar resposta da fatlog: {}, cause: {}", ex.getMessage(), ex.getCause());
            billingResponse.setStatus(999);
            billingResponse.setMessage("Ocorreu uma falha no processamento");
        }
        return billingResponse;
    }
}

