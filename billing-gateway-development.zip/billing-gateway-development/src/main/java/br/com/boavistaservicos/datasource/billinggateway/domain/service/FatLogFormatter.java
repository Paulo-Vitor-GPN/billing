package br.com.boavistaservicos.datasource.billinggateway.domain.service;


import br.com.boavistaservicos.datasource.billinggateway.domain.models.as400.FatLog;
import br.com.boavistaservicos.datasource.billinggateway.domain.models.as400.InformacaoSistemaAssunto;
import br.com.boavistaservicos.datasource.billinggateway.domain.service.impl.BillingServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Random;
import java.util.UUID;

@Service
public class FatLogFormatter {

    private static final String SPC_20 = StringUtils.rightPad(" ", 20);
    private static final String SPC_10 = StringUtils.rightPad(" ", 10);
    private static final String SPC_8 = StringUtils.rightPad("", 8);
    private static final String SPC_3 = "   ";
    private static final DateTimeFormatter DTF_HHMMSS = DateTimeFormatter.ofPattern("HHmmss");
    private static final Logger LOGGER = LoggerFactory.getLogger(FatLogFormatter.class);

    public String formatToSendToAs(FatLog fatLog, String socketServiceCodigo, String socketServiceSenha) {
        StringBuilder requestToAs400 = new StringBuilder();
        LOGGER.info("Etapa: {}, Message: {}, CODIGO DE SERVICO: {}, ACESSO: {}", "Mapper - fatlog", socketServiceCodigo.toString(), socketServiceSenha.toString());
        requestToAs400.append("CSR60   ")
                .append("01")
                .append(SPC_10)
                .append(SPC_20)
                .append(StringUtils.leftPad(socketServiceCodigo, 8, "0"))
                .append(StringUtils.rightPad(socketServiceSenha, 8))
                .append("FATLOG  ")
                .append("07")
                .append(2)
                .append("T")
                .append(1)
                .append(StringUtils.leftPad(fatLog.getDocumento().trim(), 14, "0"))
                .append(StringUtils.leftPad(fatLog.getCodigoCliente(), 8, "0")).append(SPC_3)
                .append(SPC_8)
                .append(StringUtils.rightPad(fatLog.getInternetProtocolConsulente() == null ? " " : fatLog.getInternetProtocolConsulente(), 15))
                .append("IC")
                .append(StringUtils.rightPad(fatLog.getTransactionId() == null ? UUID.randomUUID().toString() : fatLog.getTransactionId(), 38, " "))
                .append(SPC_20)
                .append(StringUtils.rightPad(converterSistemaAssuntoList(fatLog.getInformacaoSistemaAssuntoList()), 700))
                .append(SPC_10);
        LOGGER.info("Etapa: {}, Message: {}, fatlog: {}", "Mapper - fatlog", "fatlog formatada: ", requestToAs400.toString());
        return requestToAs400.toString();
    }

    private String converterSistemaAssuntoList(List<InformacaoSistemaAssunto> sistemaAssuntoList) {
        StringBuilder sb = new StringBuilder();
        sistemaAssuntoList.forEach(isa -> {
            sb.append(StringUtils.rightPad(isa.getCodigoSistema(), 3))
                    .append(StringUtils.rightPad(isa.getCodigoAssunto(), 3))
                    .append("N")
                    .append(isa.getTipoFaturamento())
                    .append(localDateTime2hhmmss(isa.getMomentoConsulta()));
        });
        return sb.toString();
    }

    private String localDateTime2hhmmss(LocalDateTime localDateTime) {
        return localDateTime.format(DTF_HHMMSS);
    }
}