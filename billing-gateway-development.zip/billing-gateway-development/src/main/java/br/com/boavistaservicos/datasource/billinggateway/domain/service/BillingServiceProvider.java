package br.com.boavistaservicos.datasource.billinggateway.domain.service;

import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingRequest;
import br.com.boavistaservicos.datasource.billinggateway.domain.dto.DataSourceBillingResponse;
import br.com.boavistaservicos.datasource.billinggateway.domain.models.AuthenticationToken;


public interface BillingServiceProvider {

   DataSourceBillingResponse billing(final DataSourceBillingRequest requestBody);
}
