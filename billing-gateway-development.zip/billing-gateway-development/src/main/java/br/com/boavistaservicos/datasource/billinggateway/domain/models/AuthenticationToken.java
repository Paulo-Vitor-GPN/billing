package br.com.boavistaservicos.datasource.billinggateway.domain.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuthenticationToken {

    @JsonProperty("token")
    private String token;
}